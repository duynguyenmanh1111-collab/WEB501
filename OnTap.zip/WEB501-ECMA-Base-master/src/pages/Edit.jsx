function EditPage() {
  return (
    <div>
      <h1>Cập nhật</h1>
    </div>
  );
}

export default EditPage;
